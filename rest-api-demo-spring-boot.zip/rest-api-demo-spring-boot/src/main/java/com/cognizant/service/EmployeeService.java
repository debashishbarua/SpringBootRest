package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cognizant.model.Employee;
import com.cognizant.service.exception.EmployeeNotFoundException;

@Service
public class EmployeeService {

	private static List<Employee> employees;

	static {
		employees = new ArrayList<>();
		employees.add(new Employee(10L, "Akash", "Verma"));
		employees.add(new Employee(11L, "Aman", "Verma"));
		employees.add(new Employee(12L, "Ajay", "Verma"));
		employees.add(new Employee(13L, "Anuj", "Verma"));

	}

	public List<Employee> findAllEmployee() {
		return employees;
	}

	public Employee findEmployeeById(long id) throws EmployeeNotFoundException {
		Optional<Employee> employeeOptional = employees.stream().filter(e -> e.getId() == id).findFirst();
		if (employeeOptional.isPresent()) {
			return employeeOptional.get();
		}
		throw new EmployeeNotFoundException("Employee Not Present with id :" + id);
	}

	public Employee ceateEmployee(Employee employee) {
		if (employees.add(employee)) {
			return employee;
		}
		throw new RuntimeException("Employee Not Created");

	}

}
