package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/employees")
	public List<Employee> findAllEmployee(){
		return employeeService.findAllEmployee();
	}

	@GetMapping("/employees/{id}")
	public Employee findEmployeeById(@PathVariable("id") long id){
		return employeeService.findEmployeeById(id);
	}
	
	@PostMapping("/employees")
	public Employee ceateEmployee(@RequestBody Employee employee){
		return employeeService.ceateEmployee(employee);
	}

	@DeleteMapping("/employees/{id}")
	public void deleteEmployee(@PathVariable("id") long id){
		//Delete write the code
	}
}
