package com.cognizant.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	// Return All employees
	@GetMapping("/employees")
	public List<Employee> findAllEmployee() {
		return employeeService.findAllEmployee();
	}

	// http://localhost:8080/employees?id=12 @RequestParam
	// http://localhost:8080/employees/12 @PathVariable
	// This will return a single employee
	@GetMapping("/employees/{id}")
	public Employee findEmployeeById(@PathVariable("id") long id) {
		return employeeService.findEmployeeById(id);
	}

	// Posting the data to server
	// We r sending json
	// Converting json to Java object
	@PostMapping("/employees")
	public Employee ceateEmployee(@Valid @RequestBody Employee employee) {
		
		//Validation 
		
		//throw exception
	    //else
		return employeeService.ceateEmployee(employee);
	}

	@DeleteMapping("/employees/{id}")
	public void deleteEmployee(@PathVariable("id") long id) {
		// Delete write the code
	}

	// Controller Specific
	// Exception Handler Method
//	@ExceptionHandler(EmployeeNotFoundException.class)
//	public ResponseEntity<Object> employeeNotFounHandler(EmployeeNotFoundException ex) {
//		Map<String, Object> body = new LinkedHashMap<>();
//		body.put("timestamp", new Date());
//		body.put("error", "Not Found");
//		body.put("message",ex.getMessage());
//		return new ResponseEntity<>(body, new HttpHeaders(), HttpStatus.NOT_FOUND);
//	}

}
